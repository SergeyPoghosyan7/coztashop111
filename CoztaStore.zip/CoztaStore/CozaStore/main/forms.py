from django.forms import ModelForm
from .models import ContactUs, Comment



class ContactUsForm(ModelForm):
    class Meta:
        model = ContactUs
        fields = '__all__'



class CommentForm(ModelForm):
    class Meta:
        model = Comment
        fields = '__all__'


