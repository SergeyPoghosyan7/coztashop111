from django.shortcuts import render , redirect
from django.views import generic
from django.template.defaultfilters import date
from django.core.mail import send_mail
from CozaStore.settings import EMAIL_HOST_USER
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .forms import (
    ContactUsForm , CommentForm
)
from .models import *


class HomeListView(generic.ListView):
    template_name = 'index.html'

    @staticmethod
    def __extract_all_data():
        
        sliders = Slider.objects.all()

        context = {
            'nav':'home',
            'sliders':sliders,
        }   

        return context

    def get(self, request):

        return render(request, self.template_name , context = self.__extract_all_data())
    

class AboutListView(generic.ListView):
    template_name = 'about.html'

    def get(self, request):
        abouts = About.objects.all()


        context = {
            'nav':'about',
            'abouts':abouts,

        }    
        
        return render(request, self.template_name , context = context)
    


class BlogListView(generic.ListView):
    template_name = 'blog.html'
    paginate_by = 2

    @staticmethod
    def __extract_blog_data(request, items_per_page):
        blogs = Blog.objects.all()
        paginator = Paginator(blogs, items_per_page)  
        page = request.GET.get('page')

        try:
            blogs = paginator.page(page)
        except PageNotAnInteger:
            blogs = paginator.page(1)
        except EmptyPage:
            blogs = paginator.page(paginator.num_pages)

        context = {
            'nav': 'blog',
            'blogs': blogs,
        }
        return context

    def get(self, request):
        context = self.__extract_blog_data(request, self.paginate_by) 
        return render(request, self.template_name , context = context)
    

class BlogDetailView(generic.DetailView):
    template_name = 'blog-detail.html'


    @staticmethod
    def __extract_blog_data(blog_id):
        blog = Blog.objects.get(pk=blog_id)
        comments = Comment.objects.all()


        context = {
            'nav': 'blog',
            'blog' : blog,
            'comments':comments,
        } 

        return context

    def get(self, request, blog_id): 
        
        return render(request, self.template_name , context = self.__extract_blog_data(blog_id))
    
    def post(self, request, blog_id):
        blog = Blog.objects.get(pk=blog_id)
        data = request.POST.copy()
        data['blog'] = blog

        form = CommentForm(data)
        print(form.data)
        if form.is_valid():
            form.save()
        else:
            form = CommentForm()

        context = self.__extract_blog_data(blog_id)
        context.update({'form':form})
        return render(request, self.template_name, context = context)

class ContactListView(generic.ListView):
    template_name = 'contact.html'

    def get(self, request):

        info = ContactInformation.objects.get()

        context = {
            'nav':'contact',
            'info':info,

        }    
        
        return render(request, self.template_name , context = context)
    
    def post(self, request):
        form = ContactUsForm(request.POST)

        if form.is_valid():
            email = form.cleaned_data.get('email')
            send_mail(
                from_email=EMAIL_HOST_USER,
                recipient_list=[email],
                subject='CozaStore Support',
                message='We get your request',
                fail_silently=False
            )

            form.save()
        else:
            form = ContactUsForm()
        
        return render(request, self.template_name , context = {'form' : form})

class ProductListView(generic.ListView):
    template_name = 'product.html'

    def get(self, request):


        context = {
            'nav':'shop',

        }    
        
        return render(request, self.template_name , context = context)
    

class ProductDetailView(generic.DetailView):
    template_name = 'product-detail.html'

    def get(self, request, slug):
        context = {

        }    
        
        return render(request, self.template_name , context = context)
    

class ShoppingCartListView(generic.ListView):
    template_name = 'shoping-cart.html'

    def get(self, request):
        context = {
            'nav':'features',

        }    
        
        return render(request, self.template_name , context = context)
    
    
