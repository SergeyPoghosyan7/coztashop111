const url = 'http://localhost:3000/';  
const postData = {
   
      "fgh": "hello"
   
    
};

fetch('http://localhost:3000/', {
   mode: 'no-cors',
   method: "POST",
  cache: "no-cache", 
  credentials: "same-origin",
  body: JSON.stringify(postData),
  "headers":{
   "Content-type":"application/json; charset-UTF-8"
  }
})
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    
    return response.json();
  })
  .then(data => {
   
    console.log('Response:', data);
  })
  .catch(error => {
    console.error('Errossssr:', error);
  });

