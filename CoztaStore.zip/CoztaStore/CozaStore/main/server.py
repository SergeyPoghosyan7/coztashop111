import http.server
import socketserver
import json

PORT = 3000

class JSONHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
       
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()

       
        with open('data.json', 'r') as file:
            json_data = json.load(file)
            self.wfile.write(json.dumps(json_data).encode('utf-8'))

with socketserver.TCPServer(("", PORT), JSONHandler) as httpd:
    print(f"Serving at http://localhost:{PORT}")
    httpd.serve_forever()
