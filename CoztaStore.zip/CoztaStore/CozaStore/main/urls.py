from django.urls import path
from .views import (
    HomeListView, AboutListView, BlogListView, BlogDetailView,
    ContactListView, ProductListView, ProductDetailView, ShoppingCartListView
)



urlpatterns = [
    path('', HomeListView.as_view(), name='home'),
    path('about/', AboutListView.as_view(), name='about'),
    path('blogs/', BlogListView.as_view(), name='blogs'),
    path('blogs/<int:blog_id>', BlogDetailView.as_view(), name='single_blog'), # TODO: add unique indicator
    path('conact-us/', ContactListView.as_view(), name='contacts'),
    path('products/', ProductListView.as_view(), name='products'),
    path('products/<slug:slug>', ProductDetailView.as_view(), name='single_product'),# TODO: add unique indicator
    path('shopping-cart/', ShoppingCartListView.as_view(), name='cart'),
]
